Cnab a Receber - Protheus
Obs: NÃO é CNAB MODELO 2.

.rem = arquivo de remessa/envio
.ret = arquivo de retorno

qualquer dúvida
marcos122@gmail.com