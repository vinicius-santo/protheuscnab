Cnab Modelo 2 - Contas a Pagar -  Protheus
penv.2pe = pagamento envio
pret.2pr = pagamento retorno

qualquer dúvida
marcos122@gmail.com